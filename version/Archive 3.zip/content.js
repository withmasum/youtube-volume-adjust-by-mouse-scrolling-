function adjustVolumeWithScroll(video) {
  if (!video || video.dataset.volumeScrollAdded) return;

  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = '10px';
  overlay.style.left = '10px';
  overlay.style.padding = '5px 10px';
  overlay.style.background = 'rgba(0, 0, 0, 0.7)';
  overlay.style.color = 'white';
  overlay.style.fontSize = '14px';
  overlay.style.borderRadius = '5px';
  overlay.style.zIndex = '9999';
  overlay.style.display = 'none';
  overlay.style.pointerEvents = 'none';
  document.body.appendChild(overlay);

  video.dataset.volumeScrollAdded = 'true';

  video.addEventListener('wheel', (e) => {
    e.preventDefault();
    const delta = -Math.sign(e.deltaY) * 0.05;
    video.volume = Math.min(Math.max(video.volume + delta, 0), 1);
    overlay.textContent = `Volume: ${(video.volume * 100).toFixed(0)}%`;

    const rect = video.getBoundingClientRect();
    overlay.style.top = `${rect.top + 10}px`;
    overlay.style.left = `${rect.left + 10}px`;
    overlay.style.display = 'block';

    clearTimeout(overlay.timeout);
    overlay.timeout = setTimeout(() => {
      overlay.style.display = 'none';
    }, 800);
  }, { passive: false });
}

function watchForVideos() {
  const observer = new MutationObserver(() => {
    document.querySelectorAll("video").forEach(adjustVolumeWithScroll);
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Also check initially
  document.querySelectorAll("video").forEach(adjustVolumeWithScroll);
}

if (document.readyState === "complete" || document.readyState === "interactive") {
  watchForVideos();
} else {
  window.addEventListener("DOMContentLoaded", watchForVideos);
}
